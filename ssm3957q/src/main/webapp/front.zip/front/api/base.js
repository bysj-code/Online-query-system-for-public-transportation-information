﻿const base = {
        url : "http://localhost:8080/ssm3957q/"
    }
export default base